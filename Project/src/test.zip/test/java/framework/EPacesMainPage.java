package framework;

import org.openqa.selenium.By;

public class EPacesMainPage extends BasePage {

    private By requestButton = By.id("ctl00_Menu1_linkEligibilityRequest\"");
    private By enterClientIdTextField = By.id("ctl00_ContentPlaceHolder1_textBoxClientID");
    private By submitButton = By.id("ctl00_ContentPlaceHolder1_buttonSubmit");
    private By responsesButton = By.id("ctl00_Menu1_linkEligibilityResponse");
    private String clientId = "";
    private String clientIdRowBeginning = "//a[@title='";
    private String  clientIdRowEnding = "']";
    private By planNameField = By.xpath("//span[contains(text(),'VILLAGE')]");


    public void clickOnRequestButton() {
        clickOn(requestButton);
    }

    public void enterClientId(String enteredClientId) {
        this.clientId = enteredClientId;
        setValue(enterClientIdTextField, enteredClientId);
    }

    public void clickOnSubmitButton () {
        clickOn(submitButton);
    }

    public void clickOnResponsesButton() {
        clickOn(responsesButton);
    }

    public void clickOnClientId() {
        clickOn(By.xpath(clientIdRowBeginning + clientId + clientIdRowEnding));
    }

    public String getTextFromPlanName() {
        return getTextFromElement(planNameField);
    }






}
