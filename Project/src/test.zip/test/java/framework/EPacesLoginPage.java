package framework;

import org.openqa.selenium.By;

public class EPacesLoginPage extends BasePage {

    private By usernameTextField = By.id("Username");
    private By passwordTextField = By.id("Password");
    private By agreementCheckBox = By.id("chkbxAgree");
    private By agreeLoginButton = By.id("btnAgreeLogin");

    public void enterUsername(String username) {
        setValue(usernameTextField, username);
    }

    public void enterPassword(String password) {
        setValue(passwordTextField, password);
    }

    public void clickOnAgreeChecckBox() {
        clickOn(agreementCheckBox);
    }

    public void clickOnLoginButton() {
        clickOn(agreeLoginButton);
    }




}
