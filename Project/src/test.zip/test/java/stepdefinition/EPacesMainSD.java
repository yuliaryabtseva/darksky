package stepdefinition;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import framework.EPacesLoginPage;
import framework.EPacesMainPage;
import org.testng.Assert;

public class EPacesMainSD {

    EPacesLoginPage ePacesLoginPage = new EPacesLoginPage();
    EPacesMainPage ePacesMainPage = new EPacesMainPage();

    @Given("^I am on ePaces main page$")
    public void iAmOnEpacesMainPage() {
        ePacesLoginPage.enterUsername("NIskhaki");
        ePacesLoginPage.enterPassword("Intakegirls2020");
        ePacesLoginPage.clickOnAgreeChecckBox();
        ePacesLoginPage.clickOnLoginButton();
        Assert.assertEquals(SharedSD.getDriver().getCurrentUrl(), "https://www.emedny.org/epaces/", "Wrong Login page");
    }

    @When("^I enter (.*) into Enter Client Id text field on ePaces main page$")
    public void enterClientId() {
        ePacesMainPage.clickOnClientId();
        ePacesMainPage.clickOnSubmitButton();
    }

    @When("^I go to Responses webpage$")
    public void goToResponsesPage() {
        ePacesMainPage.clickOnResponsesButton();
    }

    @Then("^I verify that client has VillageCare plan$")
    public void verifyPlan() {
        ePacesMainPage.clickOnClientId();
        ePacesMainPage.getTextFromPlanName();
        Assert.assertEquals(, "https://www.emedny.org/epaces/", "Wrong Login page");

    }


}
